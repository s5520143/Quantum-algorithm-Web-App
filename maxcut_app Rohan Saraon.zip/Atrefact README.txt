REQUIRED PACKAGES:

- qiskit
- qiskit_aer
- streamlit
- matplotlib
- networkx


For testing purposes I would reccomend using the Greedy algorithm for testing the graph settings due to the long runtimes of the other available options.

After installing everything, run the application at least once and type "streamlit run maxcut_app.py" into the terminal and a tab on your browser with the application will open